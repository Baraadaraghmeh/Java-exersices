/*
 * Programming Quiz: Favorite Food 
 * Create a string with the name of your favorite food. The first letter of the string should be capitalized.
 */

console.log(/* replace this comment with your string */);
