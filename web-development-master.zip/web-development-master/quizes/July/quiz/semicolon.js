/*
 * Programming Quiz: Semicolons! 
 * Define two variables called thingOne and thingTwo and assign them values. 
 * Print the values of both variables in one console.log statement using concatenation. For example,
 * red blue
 * where "red" is the value of thingOne and "blue" is the value of thingTwo. Don't forget to use semicolons!
 */

// your code goes here
