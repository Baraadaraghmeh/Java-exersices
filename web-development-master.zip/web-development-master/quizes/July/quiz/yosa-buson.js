/*
 * Programming Quiz: Yosa Buson 
 * Build a string using concatenation by combining the lines from this famous haiku poem by Yosa Buson.
 * Blowing from the west
 * Fallen leaves gather
 * In the east.
 * Each string should be printed on its own line.

 * Hint: You will need to use special characters to produce the following output. For a refresher, feel free to review the previous Escaping Strings lesson in this course.
 */


var haiku = /* concatenate the strings here */
console.log(haiku);
