/*
 * Programming Quiz: All Tied Up 
 * Build a single string that resembles the following joke.
 *
 * Why couldn't the shoes go out and play?
 * They were all "tied" up!
 * Your joke should take the format of a question and answer. 
 * The first line should be a question and the second line should be an answer.
 * Hint: You will need to use special characters to produce the following output.*/
 console.log("Why couldn't the shoes go out and play?\n ");
 console.log("They were all \"tied"\" up!"); 